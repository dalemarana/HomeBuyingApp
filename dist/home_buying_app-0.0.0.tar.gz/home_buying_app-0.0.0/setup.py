from setuptools import setup, find_packages

# setup(
#     name='home_buying_app',
#     version='0.1',
#     packages=find_packages(),
#     install_requires=[],
# )

if __name__ == "__main__":
    setup()