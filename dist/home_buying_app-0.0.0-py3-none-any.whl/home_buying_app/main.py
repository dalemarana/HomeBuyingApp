import gui  # Importing the GUI module

if __name__ == "__main__":
    gui.run()  # Ensure `gui.py` has a `run()` function that launches the GUI